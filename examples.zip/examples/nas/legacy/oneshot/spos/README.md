[Documentation](https://nni.readthedocs.io/en/latest/NAS/SPOS.html)
