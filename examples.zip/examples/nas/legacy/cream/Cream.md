[Documentation](https://nni.readthedocs.io/en/latest/NAS/Cream.html)
