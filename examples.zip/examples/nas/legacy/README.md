# NAS Examples (legacy)

Please note that the examples in this folder are marked as legacy and unmaintained.

For latest examples, please read the [documentation](https://nni.readthedocs.io/en/latest/).
