# Examples

This folder contains the examples of new compression version (NNI 3.0).

## ./evaluator

If you want to view how to initialize a evaluator you need, please refer this example folder.
