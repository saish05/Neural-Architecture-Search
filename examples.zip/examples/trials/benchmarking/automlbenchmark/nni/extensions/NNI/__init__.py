# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

def run(*args, **kwargs):
    from .exec import run
    return run(*args, **kwargs)
